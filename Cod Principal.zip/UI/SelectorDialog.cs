﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ActAditionalPlugin.Models;

namespace ActAditionalPlugin.UI
{
    /// <summary>
    /// Selector unificat cu 4 categorii cromatice:
    /// Acte Adiționale (Albastru) | Decizii Suspendare (Teal) | Decizii Încetare (Rose) | Procese Verbale (Amber).
    /// </summary>
    public sealed class SelectorDialog : Form
    {
        public DocumentSelection Selection { get; private set; }

        // ── Definitii carduri ──────────────────────────────────
        private static readonly (string Cat, string Titlu, string Sub, DocumentSelection Sel, DocumentTheme Theme)[] Entries =
        {
            // Acte Adiționale
            ("ACTE ADIȚIONALE",
             "Act Adițional", "Modificare clauze contract individual de muncă",
             new DocSelection(TipDocument.ActAditional), DocumentTheme.Acte),

            // Decizii — Suspendare
            ("DECIZII — SUSPENDARE",
             "Creștere copil", "Art. 51 alin. 1 lit. a Codul Muncii",
             new DocSelection(TipDocument.SuspendareCresterecopil), DocumentTheme.Suspendare),
            ("DECIZII — SUSPENDARE",
             "Creștere copil handicap", "Art. 51 alin. 1 lit. b",
             new DocSelection(TipDocument.SuspendareCresterecopilHandicap), DocumentTheme.Suspendare),
            ("DECIZII — SUSPENDARE",
             "Absențe nemotivate", "Art. 51 alin. 2",
             new DocSelection(TipDocument.SuspendareAbsenteNemotivate), DocumentTheme.Suspendare),
            ("DECIZII — SUSPENDARE",
             "Acordul părților", "Art. 54",
             new DocSelection(TipDocument.SuspendareAcordParti), DocumentTheme.Suspendare),
            ("DECIZII — SUSPENDARE",
             "Suspendare + Încetare", "Suspendare cu clauză de încetare",
             new DocSelection(TipDocument.SuspendareSiIncetareSuspendare), DocumentTheme.Suspendare),

            // Decizii — Încetare
            ("DECIZII — ÎNCETARE",
             "Încetare suspendare", "Reluare activitate",
             new DocSelection(TipDocument.IncetareSuspendare), DocumentTheme.Incetare),
            ("DECIZII — ÎNCETARE",
             "Demisie", "Art. 81 Codul Muncii",
             new DocSelection(TipDocument.IncetareDemisie), DocumentTheme.Incetare),
            ("DECIZII — ÎNCETARE",
             "Expirare termen", "CIM pe durată determinată",
             new DocSelection(TipDocument.IncetareExpirare), DocumentTheme.Incetare),
            ("DECIZII — ÎNCETARE",
             "Disciplinar", "Art. 61 lit. a Codul Muncii",
             new DocSelection(TipDocument.IncetareDisciplinar), DocumentTheme.Incetare),

            // Procese Verbale
            ("PROCESE VERBALE",
             "Echipamente", "Uniformă, unelte, echipament de protecție",
             new PvSelection(TipPV.Echipamente), DocumentTheme.Pv),
            ("PROCESE VERBALE",
             "Electronice", "Laptop, telefon, tabletă, accesorii",
             new PvSelection(TipPV.Electronice), DocumentTheme.Pv),
            ("PROCESE VERBALE",
             "Autovehicul", "Predare-primire vehicul de serviciu",
             new PvSelection(TipPV.Autovehicul), DocumentTheme.Pv),
        };

        private int _selectedIndex = -1;
        private Button[] _cards;
        private Button _btnContinua;

        public SelectorDialog()
        {
            Text = "Generator Documente HR";
            Size = new Size(1400, 800);
            FormBorderStyle = FormBorderStyle.Sizable;
            MinimumSize = new Size(860, 680);
            MaximizeBox = true;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Color.FromArgb(242, 245, 250);
            Font = new Font("Segoe UI", 10f);
            BuildUI();
        }

        private void BuildUI()
        {
            // Header neutru (nu e asociat niciunei categorii)
            var pnlHeader = new Panel { Dock = DockStyle.Top, Height = 70, BackColor = Color.FromArgb(66, 76, 103) };
            pnlHeader.Controls.Add(new Label
            {
                Text = "Generator Documente HR",
                Font = new Font("Segoe UI", 15f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 10)
            });
            pnlHeader.Controls.Add(new Label
            {
                Text = "Selectează tipul documentului",
                Font = new Font("Segoe UI", 9f),
                ForeColor = Color.FromArgb(180, 195, 215),
                AutoSize = true,
                Location = new Point(20, 44)
            });

            // Footer
            var pnlFooter = new Panel { Dock = DockStyle.Bottom, Height = 56, BackColor = Color.White };
            pnlFooter.Paint += (s, e) =>
            {
                using (var pen = new Pen(Color.FromArgb(210, 220, 235)))
                    e.Graphics.DrawLine(pen, 0, 0, pnlFooter.Width, 0);
            };

            _btnContinua = new Button
            {
                Text = "Continuă  →",
                Size = new Size(140, 36),
                FlatStyle = FlatStyle.Flat,
                BackColor = ButtonPalettes.PrimaryDisabledBack,
                ForeColor = ButtonPalettes.PrimaryDisabledFore,
                Font = new Font("Segoe UI", 10f),
                Enabled = false,
                Top = 10
            };
            _btnContinua.FlatAppearance.BorderSize = 0;
            _btnContinua.MouseEnter += (s, e) => { if (_btnContinua.Enabled) _btnContinua.BackColor = ButtonPalettes.Primary.Hover; };
            _btnContinua.MouseLeave += (s, e) => { if (_btnContinua.Enabled) _btnContinua.BackColor = ButtonPalettes.Primary.Background; };
            _btnContinua.Click += (s, e) => Confirma();

            var btnAnuleaza = new Button
            {
                Text = "Anulează",
                Size = new Size(100, 36),
                Font = new Font("Segoe UI", 10f),
                Top = 10
            };
            ButtonPalettes.Secondary.ApplyTo(btnAnuleaza);
            btnAnuleaza.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };

            pnlFooter.Controls.AddRange(new Control[] { _btnContinua, btnAnuleaza });
            pnlFooter.Resize += (s, e) =>
            {
                _btnContinua.Left = pnlFooter.Width - _btnContinua.Width - 16;
                btnAnuleaza.Left = _btnContinua.Left - btnAnuleaza.Width - 8;
            };
            _btnContinua.Left = 688; btnAnuleaza.Left = 580;

            var scroll = new Panel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                Padding = new Padding(16, 12, 16, 8),
                BackColor = Color.FromArgb(242, 245, 250)
            };

            _cards = new Button[Entries.Length];
            BuildCards(scroll);

            Controls.Add(scroll);
            Controls.Add(pnlFooter);
            Controls.Add(pnlHeader);
            AcceptButton = _btnContinua;
            CancelButton = btnAnuleaza;
        }
        private void BuildCards(Panel scroll)
        {
            const int CardW = 250, CardH = 75, GapX = 8, GapY = 6;

            var groups = new System.Collections.Generic.List<(Label lbl, Panel bar, FlowLayoutPanel flow, int count)>();

            int i = 0;
            while (i < Entries.Length)
            {
                string cat = Entries[i].Cat;
                var catTheme = Entries[i].Theme;

                var lbl = new Label { Text = cat, Font = new Font("Segoe UI", 8f, FontStyle.Bold), ForeColor = catTheme.AccentDark, AutoSize = false, Height = 20 };
                var bar = new Panel { Height = 2, BackColor = catTheme.AccentBorder };
                var flow = new FlowLayoutPanel { FlowDirection = FlowDirection.LeftToRight, WrapContents = true, BackColor = Color.Transparent };

                scroll.Controls.Add(lbl);
                scroll.Controls.Add(bar);
                scroll.Controls.Add(flow);

                int catStart = i;
                while (i < Entries.Length && Entries[i].Cat == cat) i++;

                for (int j = catStart; j < i; j++)
                {
                    var btn = BuildCard(j, CardW, CardH, GapX, GapY);
                    _cards[j] = btn;
                    flow.Controls.Add(btn);
                }

                groups.Add((lbl, bar, flow, i - catStart));
            }

            Action relayout = () =>
            {
                int w = Math.Max(scroll.ClientSize.Width - scroll.Padding.Horizontal - 8, CardW + 8);
                int y = 8;
                bool first = true;

                foreach (var g in groups)
                {
                    if (!first) y += 12;
                    first = false;

                    g.lbl.SetBounds(4, y, w, 20);
                    y += 24;
                    g.bar.SetBounds(4, y, w, 2);
                    y += 8;

                    int cols = Math.Max(w / (CardW + GapX), 1);
                    int rows = (g.count + cols - 1) / cols;
                    int flowH = rows * (CardH + GapY);
                    g.flow.SetBounds(4, y, w, flowH);
                    y += flowH;
                }
            };

            scroll.Resize += (s, e) => relayout();
            relayout();
        }

        private Button BuildCard(int index, int cardW, int cardH, int gapX, int gapY)
        {
            var (_, titlu, sub, _, theme) = Entries[index];
            var btn = new Button
            {
                Size = new Size(cardW, cardH),
                Margin = new Padding(0, 0, gapX, gapY),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.White,
                Cursor = Cursors.Hand,
                Tag = index
            };
            btn.FlatAppearance.BorderColor = theme.AccentBorder;
            btn.FlatAppearance.BorderSize = 1;
            btn.Paint += (s, e) => DrawCard(e.Graphics, btn, titlu, sub, theme);
            btn.Click += CardClick;
            btn.MouseEnter += (s, e) => { if ((int)btn.Tag != _selectedIndex) { btn.BackColor = theme.AccentPal; btn.Invalidate(); } };
            btn.MouseLeave += (s, e) => { if ((int)btn.Tag != _selectedIndex) { btn.BackColor = Color.White; btn.Invalidate(); } };
            btn.DoubleClick += (s, e) => { CardClick(s, e); Confirma(); };
            return btn;
        }


        private static void DrawCard(Graphics g, Button btn, string titlu, string sub, DocumentTheme theme)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            bool sel = (int)btn.Tag == ((SelectorDialog)btn.FindForm())._selectedIndex;

            // Bara accent sus (3px)
            g.FillRectangle(new SolidBrush(sel ? theme.Accent : theme.AccentBorder), 0, 0, btn.Width, 3);

            // Border selectie
            if (sel)
                using (var pen = new Pen(theme.Accent, 2))
                    g.DrawRectangle(pen, 1, 1, btn.Width - 3, btn.Height - 3);

            // Icon document
            int ix = 14, iy = 18;
            g.FillRectangle(new SolidBrush(theme.AccentPal), ix, iy, 20, 26);
            using (var pen = new Pen(theme.AccentBorder))
            {
                g.DrawRectangle(pen, ix, iy, 20, 26);
                for (int li = 0; li < 3; li++)
                    g.DrawLine(pen, ix + 3, iy + 7 + li * 6, ix + 17, iy + 7 + li * 6);
            }

            // Text
            using (var brMain = new SolidBrush(Color.FromArgb(25, 35, 55)))
                g.DrawString(titlu, new Font("Segoe UI", 10f, FontStyle.Bold), brMain,
                    new RectangleF(42, 10, btn.Width - 50, 22));
            using (var brSub = new SolidBrush(Color.FromArgb(90, 105, 130)))
                g.DrawString(sub, new Font("Segoe UI", 8.5f), brSub,
                    new RectangleF(42, 33, btn.Width - 50, 34));

            // Checkmark selectie
            if (sel)
            {
                g.FillEllipse(new SolidBrush(theme.Accent), btn.Width - 22, btn.Height - 22, 16, 16);
                using (var pen = new Pen(Color.White, 1.8f) { StartCap = LineCap.Round, EndCap = LineCap.Round })
                    g.DrawLines(pen, new[]
                    {
                        new Point(btn.Width - 18, btn.Height - 13),
                        new Point(btn.Width - 15, btn.Height - 10),
                        new Point(btn.Width - 9,  btn.Height - 16)
                    });
            }
        }

        private void CardClick(object sender, EventArgs e)
        {
            int idx = (int)((Button)sender).Tag;
            _selectedIndex = idx;
            Selection = Entries[idx].Sel;
            var theme = Entries[idx].Theme;

            foreach (var btn in _cards)
            {
                bool isSel = (int)btn.Tag == idx;
                btn.BackColor = isSel ? Entries[(int)btn.Tag].Theme.AccentPal : Color.White;
                btn.Invalidate();
            }

            _btnContinua.Enabled = true;
            _btnContinua.BackColor = ButtonPalettes.Primary.Background;
            _btnContinua.ForeColor = ButtonPalettes.Primary.Foreground;
            _btnContinua.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            _btnContinua.Cursor = Cursors.Hand;
        }

        private void Confirma()
        {
            if (Selection == null) return;
            DialogResult = DialogResult.OK;
            Close();
        }
    }
}